import java.util.List;

class Data {
    List<Vital> vitals;
}
