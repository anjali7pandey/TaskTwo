
class Vital {
    int e;  // event value
    long t; // timestamp
}
